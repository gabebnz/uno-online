import React from 'react';

export default function Uno(){
    
    return(
        <div>
            <h1>Uno</h1>
        </div>
    )
}